let sunX = 100; // Posição inicial do sol
let sunY = 100;
let sunSpeed = 1; // Velocidade de movimento do sol

function setup() {
   createCanvas(800, 600);
}

function draw() {
   background(173, 216,230); // Céu azul claro

// Sol
fill(255,223,0);
ellipse(sunX, sunY, 100, 100);

// Movimento do sol
sunX += sunSpeed;
if (sunX > width + 50) {
 sunX = -50;
}

  
  // Campo
  fill(102, 205, 0);
  rect(0, height*0.7, width, height*0.3);
  
  //Árvores
  drawTree(200, height*0.6);
  drawTree(500, height*0.55);
  drawTree(700, height*0.65);
}

function drawTree(x, y) {
  // Tronco da árvore
  fill(139, 69, 19);
  rect(x - 15, y - 50, 30, 50);
  
  // Copas da árvore
  fill(0, 128, 0);
  ellipse(x, y - 80, 120, 120);
  ellipse(x - 40, y - 80, 120, 120);
  ellipse(x + 40, y - 80, 120, 120);
}
  
  